import { 
  Container, 
  Paper, 
  Typography, 
  Table, 
  TableHead, 
  TableBody, 
  TableRow, 
  TableCell, 
  TableContainer,
  Button,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Box
} from "@mui/material";
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { useState, type SetStateAction } from 'react';
import { Navbar1 } from "../components";

const ModificarUsuario = () => {
  // Datos de ejemplo simulados
  const initialUsers = [
    { id: 1, cedula: '001-0102030', nombres: 'Ana', apellidos: 'García', tipoUsuario: 'Estudiante' },
    { id: 2, cedula: '001-0405060', nombres: 'Luis', apellidos: 'Martínez', tipoUsuario: 'Profesor' },
    { id: 3, cedula: '001-0708090', nombres: 'Marta', apellidos: 'Sánchez', tipoUsuario: 'Administrador' },
    { id: 4, cedula: '001-1234567', nombres: 'Carlos', apellidos: 'Rodríguez', tipoUsuario: 'Estudiante' },
    { id: 5, cedula: '001-7654321', nombres: 'Sofía', apellidos: 'Fernández', tipoUsuario: 'Profesor' },
  ];

  const [users, setUsers] = useState(initialUsers);
  const [open, setOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState(null);

  // Manejar apertura del diálogo de edición
  const handleOpenEdit = (user: SetStateAction<null>) => {
    setSelectedUser({...user});
    setOpen(true);
  };

  // Manejar apertura del diálogo de eliminación
  const handleOpenDelete = (user: SetStateAction<null>) => {
    setUserToDelete(user);
    setDeleteDialogOpen(true);
  };

  // Cerrar diálogos
  const handleClose = () => {
    setOpen(false);
    setDeleteDialogOpen(false);
  };

  // Guardar cambios
  const handleSave = () => {
    setUsers(users.map(user => 
      user.id === selectedUser.id ? selectedUser : user
    ));
    handleClose();
  };

  // Confirmar eliminación
  const handleConfirmDelete = () => {
    setUsers(users.filter(user => user.id !== userToDelete.id));
    handleClose();
  };

  // Manejar cambios en los campos del formulario
  const handleChange = (e) => {
    const { name, value } = e.target;
    setSelectedUser(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <>
      <Navbar1 />
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" gutterBottom sx={{ mb: 3 }}>
          Listado de Usuarios
        </Typography>
        
        <TableContainer component={Paper}>
          <Table sx={{ minWidth: 650 }} aria-label="tabla de usuarios">
            <TableHead>
              <TableRow sx={{ bgcolor: 'primary.main' }}>
                <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Cédula</TableCell>
                <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Nombres</TableCell>
                <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Apellidos</TableCell>
                <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Tipo de Usuario</TableCell>
                <TableCell sx={{ color: 'white', fontWeight: 'bold', width: '150px' }}>Acciones</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {users.map((user) => (
                <TableRow key={user.id} hover>
                  <TableCell>{user.cedula}</TableCell>
                  <TableCell>{user.nombres}</TableCell>
                  <TableCell>{user.apellidos}</TableCell>
                  <TableCell>{user.tipoUsuario}</TableCell>
                  <TableCell>
                    <IconButton 
                      color="primary"
                      onClick={() => handleOpenEdit(user)}
                      aria-label="editar"
                      sx={{ mr: 1 }}
                    >
                      <EditIcon />
                    </IconButton>
                    <IconButton 
                      color="error"
                      onClick={() => handleOpenDelete(user)}
                      aria-label="eliminar"
                    >
                      <DeleteIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        {/* Diálogo de modificación */}
        <Dialog open={open} onClose={handleClose}>
          <DialogTitle>Modificar Usuario</DialogTitle>
          <DialogContent>
            {selectedUser && (
              <Box component="form" sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 2 }}>
                <TextField
                  name="cedula"
                  label="Cédula"
                  value={selectedUser.cedula}
                  onChange={handleChange}
                  fullWidth
                />
                <TextField
                  name="nombres"
                  label="Nombres"
                  value={selectedUser.nombres}
                  onChange={handleChange}
                  fullWidth
                />
                <TextField
                  name="apellidos"
                  label="Apellidos"
                  value={selectedUser.apellidos}
                  onChange={handleChange}
                  fullWidth
                />
                <TextField
                  name="tipoUsuario"
                  label="Tipo de Usuario"
                  value={selectedUser.tipoUsuario}
                  onChange={handleChange}
                  fullWidth
                />
              </Box>
            )}
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose}>Cancelar</Button>
            <Button onClick={handleSave} color="primary" variant="contained">
              Guardar
            </Button>
          </DialogActions>
        </Dialog>

        {/* Diálogo de confirmación para eliminar */}
        <Dialog open={deleteDialogOpen} onClose={handleClose}>
          <DialogTitle>Confirmar Eliminación</DialogTitle>
          <DialogContent>
            <Typography>
              ¿Estás seguro que deseas eliminar al usuario {userToDelete?.nombres} {userToDelete?.apellidos}?
            </Typography>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose}>Cancelar</Button>
            <Button 
              onClick={handleConfirmDelete} 
              color="error" 
              variant="contained"
              startIcon={<DeleteIcon />}
            >
              Eliminar
            </Button>
          </DialogActions>
        </Dialog>

        <Button 
          variant="text" 
          startIcon={<ArrowBackIcon />}
          sx={{ 
            marginTop: 2,
            color: 'primary.main',
            '&:hover': {
              backgroundColor: 'action.hover'
            }
          }}
        >
          REGRESAR
        </Button>
      </Container>
    </>
  );
};

export default ModificarUsuario;