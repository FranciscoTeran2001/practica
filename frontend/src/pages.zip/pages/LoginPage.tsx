import { Avatar, Paper, Container, Typography, Box, TextField, Button,FormControl, FormControlLabel, Grid, InputAdornment, IconButton } from "@mui/material";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import { Link } from "react-router-dom";
import { useState } from "react";
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';


const LoginPage = () => {
    const handleSubmit = () =>console.log("login")

        const [showPassword, setShowPassword] = useState(false);
    
        const handleClickShowPassword = () => setShowPassword((show) => !show);
    
        const handleMouseDownPassword = (event: React.MouseEvent<HTMLButtonElement>) => {
            event.preventDefault();
        };
    
        const handleMouseUpPassword = (event: React.MouseEvent<HTMLButtonElement>) => {
            event.preventDefault();
        };
    return(
        <Container maxWidth="xs">
            <Paper elevation={10} sx={{marginTop:8,padding:2} }>
                <Avatar sx={{mx: 'auto', bgcolor: 'secondary.main', textAlign:"center",mb:1}}>
                    <LockOutlinedIcon/>
                </Avatar>

                <Typography component='h1' variant="h5" sx={{textAlign:"center"}}>
                    Iniciar Sesion
                </Typography>

                <Box component="form" onSubmit={handleSubmit} noValidate sx={{mt:1}}>
                    <TextField placeholder="Ingresa cedula" fullWidth required autoFocus sx={{mb:2}}/>

                     <TextField
                        fullWidth
                        type={showPassword ? 'text' : 'password'}
                        label="Contraseña"
                        InputProps={{
                            endAdornment: (
                                <InputAdornment position="end">
                                    <IconButton
                                        aria-label={showPassword ? 'hide the password' : 'display the password'}
                                        onClick={handleClickShowPassword}
                                        onMouseDown={handleMouseDownPassword}
                                        onMouseUp={handleMouseUpPassword}
                                        edge="end"
                                    >
                                        {showPassword ? <VisibilityOff /> : <Visibility />}
                                    </IconButton>
                                </InputAdornment>
                            )
                        }}
                    />

                    <Button type="submit" variant="contained" fullWidth sx={{mt:1}}>
                        Iniciar Sesion
                    </Button>
                </Box>
                    <Button component={Link}
                     to="/recuperacion" 
                     sx={{ textTransform: "none" }}>Olvidaste tu contraseña?</Button>
              </Paper>
        </Container>
    )
};

export default LoginPage