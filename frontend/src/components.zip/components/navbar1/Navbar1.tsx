import { AppBar, Box, Button, CssBaseline, Divider, Drawer, IconButton, List, ListItem, ListItemButton, ListItemText, Toolbar, Typography } from "@mui/material";
import MenuIcon from '@mui/icons-material/Menu';

import React from "react"

type Props = {
    window?: ()=>Window;
  };


const drawerWidth = 240;
const navItems =['Pagina Principal','Registrar Usuario','Modificar Usuario','Estudiantes','Profesores','Cerrar Sesion'];

export const Navbar1 =(props:Props)=>{
    const {window} = props;
    const[mobileOpen,setMobileOpen] = React.useState(false);
    const handleDrawerToogle = () =>{
        setMobileOpen((prevState) => !prevState);
    };

    const drawer =(
        <Box onClick = {handleDrawerToogle} sx={{textAlign:'center'}}>
            <Typography variant="h6" sx = {{my:2}}>
                Liceo La Siembra
            </Typography>
            <Divider/>
            <List>
                {navItems.map((item)=>(
                    <ListItem key={item} disablePadding>
                        <ListItemButton sx={{textAlign:'center'}}>
                            <ListItemText primary={item}/>
                        </ListItemButton>
                    </ListItem>
                ))}
            </List>
        </Box>
    );

    const container = window !== undefined ? () => window().document.body : undefined;

    return(
        <Box sx={{display:'flex'}}>
            <CssBaseline/>
            <AppBar component='nav' sx={{bgcolor: 'gray'}}>
                <Toolbar>
                    <IconButton sx={{mr:2, display: {sm:'none'}}} color="inherit" aria-label="open drawer" edge="start" onClick={handleDrawerToogle}>
                        <MenuIcon></MenuIcon>
                    </IconButton>

                    <Typography sx={{marginRight:'auto', display: {xs: 'none', sm:'block' }}} variant="h6" component="div">
                    Liceo La Siembra
                    </Typography>
                    <Box sx={{display:{xs:'none', sm:'block'}}}>
                        {navItems.map((item)=>(
                            <Button key={item} sx={{color:'#fff'}}>
                                {item}
                            </Button>
                        ))}

                    </Box>
                </Toolbar>
            </AppBar>

            <nav>
                <Drawer container={container} variant='temporary' open={mobileOpen} onClose={handleDrawerToogle} ModalProps={{keepMounted:true}} sx={{display:{xs:'block', sm:'none'}, '& .MuiDrawer-paper':{boxSixing:'border-box',width: drawerWidth},}}>
                    {drawer}
                </Drawer>
            </nav>
        </Box>
    )
};